#include "Stack.hpp"

int main()
{
    test();
    return 1;
}